﻿#include <iostream>
#include "Matrices.h"


matrix::~matrix()
{
    delete[] data;
    data = nullptr;
    rows = 0;
    cols = 0;
}

double& matrix::operator[](int position)
{
    _ASSERT(position < this->rows * this->cols);
    return *(this->data + position);
}

size_t matrix::row_size()
{
    return this->rows;
}

size_t matrix::col_size()
{
    return this->cols;
}

int main()
{
    matrix A = matrix(2, 3);
    std::cout << "Hello World!\n" << A[2*2] << std::endl;

}

