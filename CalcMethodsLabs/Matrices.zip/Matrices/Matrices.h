#pragma once
class matrix
{
	size_t rows = 0;
	size_t cols = 0;
	double* data = nullptr;
public:
	matrix() : rows(0), cols(0), data(nullptr) {};
	matrix(size_t m, size_t n) : rows(m), cols(n), data(new double[m * n]) {};
	double& operator[](int position);

	size_t row_size();
	size_t col_size();

	~matrix();
};

//std::ostream& operator<<(std::ostream& out, const matrix& A)
//{
//	for(int i = 0; i < A.row_size(); ++i)
//		for(int j = 0; j < A.col_size(); ++j)
//		{
//
//		}
//}